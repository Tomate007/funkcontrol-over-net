var lastObjectId = "";
var readystate = false;
var wartenAufResponseParam = "";

function getQuerystring(key, default_)
{
  if (default_==null) default_=""; 
  key = key.replace(/[\[]/,"\\\[").replace(/[\]]/,"\\\]");
  var regex = new RegExp("[\\?&]"+key+"=([^&#]*)");
  var qs = regex.exec(window.location.href);
  if(qs == null)
    return default_;
  else
    return qs[1];
}

function $(id) {
return document.getElementById(id);
}
   function wartenAufResponse() {
      if (readystate == false){
      setTimeout('wartenAufResponse()', 3000);
	  } else {
	  if (wartenAufResponseParam == 'save'){
	  saveallCallback();
	  }
	  if (wartenAufResponseParam == 'receive'){
	  scanCallback();
	  }
	  if (wartenAufResponseParam == 'testcode'){
	  testcodeCallback();
	  }
	  }
	  
   }

function FrameComplete(){
readystate = true;
}


function saveall(){
lastObjectId = "";
saveallCallback();
}

function saveallCallback(){
if (lastObjectId == ""){
save("name");
return;
}
if (lastObjectId == "name"){
save("pos");
return;
}
if (lastObjectId == "pos"){
save("id");
return;
}
if (lastObjectId == "id"){
save("protocol");

return;
}
if (lastObjectId == "protocol"){
save("oncode");
return;
}
if (lastObjectId == "oncode"){
save("offcode");
return;
}
if (lastObjectId == "offcode"){
self.location.href='/'+getQuerystring('Redirect');;
}
}


function save(ObjectId){
lastObjectId = ObjectId;
readystate = false;
$('requestFrame').src='save.htm?'+ObjectId+"="+$(ObjectId).value;
wartenAufResponseParam = "save";
wartenAufResponse();
}

function splitResponse(CodeProtocol,param){
var Zaehler = 1;
var Result = "";
while (CodeProtocol != "") {
Result = CodeProtocol.substr(0,CodeProtocol.indexOf(";"));
if (Zaehler == param){
CodeProtocol = "";
} else {
CodeProtocol = CodeProtocol.replace(CodeProtocol.substr(0,CodeProtocol.indexOf(";")+1), "");
Zaehler = Zaehler+1;
}
}
return Result;
}

function scan(ObjectId) {
lastObjectId = ObjectId;
$(ObjectId).value = '';
$('status_scan_'+ObjectId).innerHTML = 'Bitte Taste auf Fernbedienung druecken...';
$('requestFrame').src='receive';
wartenAufResponseParam = "receive";
readystate = false;
wartenAufResponse();
}


function scanCallback(){
var Response = parent.frames[0].document.body.innerHTML;
if(Response.length >20){
var Code = splitResponse(Response,1);
if (Code.indexOf("1") != -1){
readystate = true;
$("id").value = getQuerystring('NewID');
$("pos").value = getQuerystring('BildId');
$(lastObjectId).value = splitResponse(Response,1);
$("protocol").value = splitResponse(Response,2);
$('status_scan_'+lastObjectId).innerHTML = 'Code gefunden!';
$('requestFrame').src='blank.htm';
}else{
scan(lastObjectId);
}
}else{
scan(lastObjectId);
}
}

function testallCodes(){
alert("Schalten Sie die Steckdose per Fernbedienung aus und klicken Sie auf OK!");
testcode("oncode");
}

function testcode(ObjectId) {
lastObjectId = ObjectId;
wartenAufResponseParam = "testcode";
readystate = false;
$('requestFrame').src='sendCode.htm?P='+$('protocol').value+$(ObjectId).value;
wartenAufResponse();
}


function testcodeCallback() {
if (lastObjectId == "oncode"){
alert("Die Dose sollte nun EINGESCHALTET sein!!");
testcode("offcode");
return;
}
if (lastObjectId == "offcode"){
lastObjectId ="";
alert("Die Dose sollte nun AUSGESCHALTET sein!!");
return;
}

}

