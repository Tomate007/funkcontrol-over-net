// JavaScript Document
var ID = "";
var AddDev=0;
var AddBildId = "";
var inOnload = true;
function onload()
{
document.getElementById("ausgabeheader").innerHTML = "<form name=\"frm\" id=\"frm\"><h1>Funkcontrol Over Net</h1>";
document.getElementById("ausgabeheader").innerHTML += "<a href=\"javascript:AddDevice();\">Ger�t hinzuf�gen</a>  - ";
document.getElementById("ausgabeheader").innerHTML += "<a href=\"javascript:chgIP();\">IP �ndern</a> - ";
document.getElementById("ausgabeheader").innerHTML += "<select name=\"DelIDSel\" id=\"DelIDSel\"><option value=\"000\" style=\"width:100px;\">---</option></select> <-- <a href=\"javascript:delID();\">l�schen</a> - </form><br>";
document.getElementById("OhnePos").innerHTML = "<h4>Ger�te ohne Zuordnung:</h4>";
getHttpRequest("save.ini");
}

function BildOnClick(BildId){
if (AddDev == 1){
if (confirm("Sind Sie sich sicher? Das Ger�t wird an die ausgew�hlte Stelle hinzugef�gt.")) { 
AddDev = 0;
AddBildId = BildId;
GoTo('AddDev.htm');
}
AddDev = 0;
}
}


function AddDevice(){
alert("Bitte klicken Sie an die Stelle wo das neue Ger�t hinzugef�gt werden soll");
AddDev = 1;
}

function delID(){
if ($('DelIDSel').value != '000'){
getHttpRequest("delete.htm?ID="+$('DelIDSel').value);
setTimeout('GoTo(\'\index2.htm\')', 3000);
}
}
function chgIP(){
var IP=prompt("Bitte geben Sie die neue IP ein (Format 12 stellen OHNE Punkt):","192.168.0.100 wie folgt eintragen 192168000100");
if (IP != null && IP.length == 12){
getHttpRequest("chgIP?"+IP);
alert("/!\IP wird ge�ndert. Bitte connecten Sie nun auf die neu eingestellte IP/!\\");
$('ausgabe').innerHTML = "IP ge�ndert<br>Bitte connecten Sie nun auf die neu eingestellte IP";
}
}


function sendCode(ID,CMD)
{
if (CMD == "ON"){
getHttpRequest("CodeOn.htm?ID="+ID);
setTimeout('GoTo(\'index2.htm\')', 3000);
}
if (CMD == "OFF"){
getHttpRequest("CodeOff.htm?ID="+ID);
setTimeout('GoTo(\'index2.htm\')', 3000);
}
}

function GoTo(filename){
variablen = "";

if (filename == "AddDev.htm"){
if (ID == ""){
variablen = "?NewID=101";
}else{
var NewID = parseInt(ID)+1;
variablen = "?NewID="+NewID;
}
if (AddBildId == ""){
variablen += "&BildId=0000";
}else{
variablen += "&BildId="+AddBildId;
}
variablen +="&Redirect=index2.htm";
}
self.location.href = "/"+filename+variablen;

}

function ParseSaveIni(responseText){
//document.getElementById("ausgabe").innerHTML = "";

var ResponseText = escape(responseText);
ResponseText = ResponseText.replace(/%0D%0A/g,"");
ResponseText = unescape(ResponseText);
var Status = "";
var Name = "";
var BildId = "";
var Protocol = "";
var OnCode = "";
var OffCode = "";

var Zaehler = 0;
while (ResponseText.length != "") {
	Zaehler = Zaehler+1;
	ResponseText.indexOf("|");
	if (Zaehler == 1){
		Name = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(Name+"|", "");
	}
    if (Zaehler == 2){
		BildId = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(BildId+"|", "");
	}
	if (Zaehler == 3){
		Status = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(Status+"|", "");
	}
	if (Zaehler == 4){
		ID = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(ID+"|", "");
	}
	if (Zaehler == 5){
		Protocol = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(Protocol+"|", "");
	}
	if (Zaehler == 6){
		OnCode = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(OnCode+"|", "");
	}
	if (Zaehler == 7){
		OffCode = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(OffCode+"|", "");
		Zaehler = 0;
		if (Status == "1"){
				 if (BildId != "0000") {
				 warten(1);
				 $("img"+BildId).src="on.gif";
				 $("img"+BildId).onclick = Function("sendCode("+ID+",'OFF')");
				 } else if (BildId == "0000"){
				 $("OhnePos").innerHTML += '<img src="on.gif" style="float:left;width:20px;heigth:20px;" onClick="javascript:sendCode(\''+ID+'\',\'OFF\');"> &nbsp;'+unescape(Name)+'<br>' ;
				 }
				 NeuerEintrag = new Option(unescape(Name), ID, false, false);
  				 $('DelIDSel').options[$('DelIDSel').length] = NeuerEintrag;

		}
		if (Status == "0"){ 
				if (BildId != "0000") {
				warten(1);
				$("img"+BildId).src="off.gif";
				$("img"+BildId).onclick = Function("sendCode("+ID+",'ON')");
				} else if (BildId == "0000"){
				$("OhnePos").innerHTML += '<img src="off.gif" style="float:left;width:20px;heigth:20px;" onClick="javascript:sendCode(\''+ID+'\',\'ON\');"> &nbsp;'+unescape(Name)+'<br>';
				}
			    NeuerEintrag = new Option(unescape(Name), ID, false, false);
  				$('DelIDSel').options[$('DelIDSel').length] = NeuerEintrag;
		}
	}
}
$("OhnePos").innerHTML += "<hr><br>";
inOnload = false;
}

function warten(prmSec) { 
prmSec *= 1000; 
var eDate = null; 
var eMsec = 0; 
var sDate = new Date(); 
var sMsec = sDate.getTime(); 
do { 
eDate = new Date();
eMsec = eDate.getTime();
} while ((eMsec-sMsec)<prmSec); 
}

function $(id) {
    return document.getElementById(id);
}
 
function getHttpRequest(dateiname) {
   
    var xmlhttp = null;
    // Mozilla
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    }
    // IE
    else if (window.ActiveXObject) {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
   
    xmlhttp.open("GET", dateiname, true);
    xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState != 4) {
			if (inOnload != true){
			$("ausgabeheader").style = "display:none;";
			$("OhnePos").innerHTML = "<hr>";
            $('ausgabe').innerHTML = 'Seite wird geladen ...';
			}
        }
        if(xmlhttp.readyState == 4 && xmlhttp.status == 200) {
		if (dateiname == "save.ini") {ParseSaveIni(xmlhttp.responseText)};
        }
    }
    xmlhttp.send(null);
}

