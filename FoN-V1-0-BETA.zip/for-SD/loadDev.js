// JavaScript Document
var ID = "";
var AddDev=0;
function onload()
{
document.getElementById("ausgabeheader").innerHTML = "<form name=\"frm\" id=\"frm\"><h1>Funkcontrol Over Net</h1>";
document.getElementById("ausgabeheader").innerHTML += "<a href=\"javascript:GoTo('AddDev.htm');\">Ger�t hinzuf�gen</a>  - ";
document.getElementById("ausgabeheader").innerHTML += "<a href=\"javascript:chgIP();\">IP �ndern</a> - ";
document.getElementById("ausgabeheader").innerHTML += "<select name=\"DelIDSel\" id=\"DelIDSel\"><option value=\"000\" style=\"width:100px;\">---</option></select> <-- <a href=\"javascript:delID();\">l�schen</a> - </form>";
getHttpRequest("save.ini");
}


function delID(){
if ($('DelIDSel').value != '000'){
getHttpRequest("delete.htm?ID="+$('DelIDSel').value);
setTimeout('GoTo(\'index.htm\')', 3000);
}
}
function chgIP(){
var IP=prompt("Bitte geben Sie die neue IP ein (Format 12 stellen OHNE Punkt):","192.168.0.100 wie folgt eintragen 192168000100");
if (IP != null && IP.length == 12){
getHttpRequest("chgIP?"+IP);
alert("/!\IP wird ge�ndert. Bitte connecten Sie nun auf die neu eingestellte IP/!\\");
$('ausgabe').innerHTML = "IP ge�ndert<br>Bitte connecten Sie nun auf die neu eingestellte IP";
}
}


function sendCode(ID,CMD)
{
if (CMD == "ON"){
getHttpRequest("CodeOn.htm?ID="+ID);
setTimeout('GoTo(\'index.htm\')', 3000);
}
if (CMD == "OFF"){
getHttpRequest("CodeOff.htm?ID="+ID);
setTimeout('GoTo(\'index.htm\')', 3000);
}
}

function GoTo(filename){
variablen = "";
if (filename == "AddDev.htm"){
if (ID == ""){
variablen = "?NewID=101&BildId=0000&Redirect=index.htm";
}else{
var NewID = parseInt(ID)+1;
variablen = "?NewID="+NewID+"&BildId=0000&Redirect=index.htm";
}
}
self.location.href = "/"+filename+variablen;

}

function ParseSaveIni(responseText){
document.getElementById("ausgabe").innerHTML = "";

var ResponseText = escape(responseText);
ResponseText = ResponseText.replace(/%0D%0A/g,"");
ResponseText = unescape(ResponseText);
var Status = "";
var Name = "";
var Protocol = "";
var OnCode = "";
var OffCode = "";
var BildId = "";
var Zaehler = 0;
while (ResponseText.length != "") {
	Zaehler = Zaehler+1;
	ResponseText.indexOf("|");
		if (Zaehler == 1){
		Name = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(Name+"|", "");
	}
    if (Zaehler == 2){
		BildId = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(BildId+"|", "");
	}
	if (Zaehler == 3){
		Status = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(Status+"|", "");
	}
	if (Zaehler == 4){
		ID = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(ID+"|", "");
	}
	if (Zaehler == 5){
		Protocol = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(Protocol+"|", "");
	}
	if (Zaehler == 6){
		OnCode = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(OnCode+"|", "");
	}
	if (Zaehler == 7){
		OffCode = ResponseText.substring(0, ResponseText.indexOf("|"));
		ResponseText = ResponseText.replace(OffCode+"|", "");
		Zaehler = 0;
		if (Status == "1"){
				document.getElementById("ausgabe").innerHTML +='<p class="active"><strong>' + unescape(Name) + '</strong><br><br>Status: <b>ON</b><br><br><a href="javascript:sendCode(\''+ID+'\',\'OFF\');">OFF</a></p>';
				  NeuerEintrag = new Option(unescape(Name), ID, false, false);
  				  $('DelIDSel').options[$('DelIDSel').length] = NeuerEintrag;

		}
		if (Status == "0"){	
				document.getElementById("ausgabe").innerHTML +='<p class="inactive"><strong>' + unescape(Name) + '</strong><br><br>Status: <b>OFF</b><br><br><a href="javascript:sendCode(\''+ID+'\',\'ON\');">ON</a></p>';
		         NeuerEintrag = new Option(unescape(Name), ID, false, false);
  				 $('DelIDSel').options[$('DelIDSel').length] = NeuerEintrag;
		}
	}
}
}

function $(id) {
    return document.getElementById(id);
}
 
function getHttpRequest(dateiname) {
   
    var xmlhttp = null;
    // Mozilla
    if (window.XMLHttpRequest) {
        xmlhttp = new XMLHttpRequest();
    }
    // IE
    else if (window.ActiveXObject) {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }
   
    xmlhttp.open("GET", dateiname, true);
    xmlhttp.onreadystatechange = function() {
        if(xmlhttp.readyState != 4) {
            $('ausgabe').innerHTML = 'Seite wird geladen ...';
        }
        if(xmlhttp.readyState == 4 && xmlhttp.status == 200) {
		if (dateiname == "save.ini") {ParseSaveIni(xmlhttp.responseText)};
        }
    }
    xmlhttp.send(null);
}

