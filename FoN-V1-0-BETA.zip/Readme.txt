Hello,
thanks for Downloading.

Please edit the "ip.ini" in "for-SD" to that IP you want.
(e.g. 192.168.1.100 = 192168001100)
Than copy the content of "for-SD" to your micro SD.

Connect your 433-Sender to Port 3 on Arduino
Connect your 433-Receiver to Port 2 on Arduino

Open the "FunkcontroloverNet.ino" (its in the "FunkcontroloverNet"-Folder) and upload it to your Arduino.

Than connect to the IP you set in "ip.ini" with your Browser.

-------------------------------------------------------------------------------------------------------------------


Hallo und danke f�r das herrunterladen.
Bitte passe die Datei "ip.ini" im Ordner "for-SD" an.
(Bsp. 192.168.1.100 = 192168001100)

Stecke dann deinen 433-Sender in den Port 3 des Arduinos
Stecke dann deinen 433-Empf�nger in den Port 2 des Arduinos

�ffne die Datei "FunkcontroloverNet.ino" im Ordner "FunkcontroloverNet" und uploade diese zum Arduino.

Dann connecte mit deinem Browser zu der IP die du in "ip.ini" eingestellt hast.